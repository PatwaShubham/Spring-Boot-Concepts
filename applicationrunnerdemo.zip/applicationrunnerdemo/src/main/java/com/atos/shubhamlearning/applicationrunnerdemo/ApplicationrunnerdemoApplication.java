package com.atos.shubhamlearning.applicationrunnerdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApplicationrunnerdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApplicationrunnerdemoApplication.class, args);
	}

}
