package com.atos.shubhamlearning.internationalizationdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InternationalizationdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
