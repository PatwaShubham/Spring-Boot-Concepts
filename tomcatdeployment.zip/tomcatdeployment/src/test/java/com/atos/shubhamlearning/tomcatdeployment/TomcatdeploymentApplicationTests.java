package com.atos.shubhamlearning.tomcatdeployment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TomcatdeploymentApplicationTests {

	@Test
	void contextLoads() {
	}

}
