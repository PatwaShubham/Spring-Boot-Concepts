package com.atos.shubhamlearning.twiliodemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TwiliodemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(TwiliodemoApplication.class, args);
	}

}
