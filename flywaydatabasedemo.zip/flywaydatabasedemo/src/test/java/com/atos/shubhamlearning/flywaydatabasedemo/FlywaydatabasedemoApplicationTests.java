package com.atos.shubhamlearning.flywaydatabasedemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlywaydatabasedemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
