package com.atos.shubhamlearning.applicationrunnerdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApplicationrunnerdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
