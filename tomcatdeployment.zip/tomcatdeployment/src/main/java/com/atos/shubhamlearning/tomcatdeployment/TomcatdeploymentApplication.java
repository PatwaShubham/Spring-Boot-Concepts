package com.atos.shubhamlearning.tomcatdeployment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TomcatdeploymentApplication {

	public static void main(String[] args) {
		SpringApplication.run(TomcatdeploymentApplication.class, args);
	}

}
